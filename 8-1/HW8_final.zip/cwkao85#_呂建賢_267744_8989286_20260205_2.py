import pygame
import random
import sys

# 初始化 Pygame
pygame.init()

# 設定視窗
WIDTH, HEIGHT = 600, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("方塊躲避遊戲 (Pygame版)")

# 顏色定義
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
GREY = (200, 200, 200)

# 遊戲參數
PLAYER_SIZE = 40
ENEMY_SIZE = 40
FPS = 60

def draw_text(surf, text, size, x, y, color=BLACK):
    # 嘗試使用微軟正黑體顯示中文，若無則使用 Arial
    try:
        font = pygame.font.SysFont("Microsoft JhengHei", size, bold=True)
    except:
        font = pygame.font.SysFont("Arial", size, bold=True)
    
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect()
    text_rect.topleft = (x, y)
    surf.blit(text_surface, text_rect)

def draw_centered_text(surf, text, size, center_x, center_y, color=BLACK):
    try:
        font = pygame.font.SysFont("Microsoft JhengHei", size, bold=True)
    except:
        font = pygame.font.SysFont("Arial", size, bold=True)
    
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect(center=(center_x, center_y))
    surf.blit(text_surface, text_rect)

class DodgeGame:
    def __init__(self):
        self.clock = pygame.time.Clock()
        self.reset_game()

    def reset_game(self):
        self.player_rect = pygame.Rect(WIDTH // 2 - PLAYER_SIZE // 2, HEIGHT - PLAYER_SIZE - 10, PLAYER_SIZE, PLAYER_SIZE)
        self.enemies = []
        self.score = 0
        self.health = 20
        self.enemy_speed = 3
        self.spawn_timer = 0
        self.is_game_over = False
        self.flash_timer = 0

    def run(self):
        while True:
            self.handle_events()
            if not self.is_game_over:
                self.update()
            self.draw()
            self.clock.tick(FPS)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        keys = pygame.key.get_pressed()
        if not self.is_game_over:
            if keys[pygame.K_LEFT] and self.player_rect.left > 0:
                self.player_rect.x -= 8
            if keys[pygame.K_RIGHT] and self.player_rect.right < WIDTH:
                self.player_rect.x += 8

    def update(self):
        self.spawn_timer += 1
        spawn_threshold = max(20, 60 - self.score)
        if self.spawn_timer >= spawn_threshold:
            x = random.randint(0, WIDTH - ENEMY_SIZE)
            self.enemies.append(pygame.Rect(x, -ENEMY_SIZE, ENEMY_SIZE, ENEMY_SIZE))
            self.spawn_timer = 0

        for enemy in list(self.enemies):
            enemy.y += self.enemy_speed
            
            if enemy.colliderect(self.player_rect):
                self.health -= 1
                self.enemies.remove(enemy)
                self.flash_timer = 10
                if self.health <= 0:
                    self.is_game_over = True
            
            elif enemy.y > HEIGHT:
                self.score += 1
                self.enemies.remove(enemy)
                if self.score % 5 == 0:
                    self.enemy_speed = min(10, 3 + self.score // 5)

        if self.flash_timer > 0:
            self.flash_timer -= 1

    def draw(self):
        screen.fill(WHITE)

        color = GREEN
        if self.flash_timer > 0:
            if (self.flash_timer // 2) % 2 == 0:
                color = GREY

        pygame.draw.rect(screen, color, self.player_rect)

        for enemy in self.enemies:
            pygame.draw.rect(screen, RED, enemy)

        draw_text(screen, f"分數: {self.score}", 24, 10, 10, BLACK)
        draw_text(screen, f"血量: {self.health}", 24, WIDTH - 120, 10, BLACK)

        if self.is_game_over:
            draw_centered_text(screen, "遊戲結束", 60, WIDTH // 2, HEIGHT // 2, BLACK)
            draw_centered_text(screen, f"最終分數: {self.score}", 30, WIDTH // 2, HEIGHT // 2 + 60, BLACK)

        pygame.display.flip()

if __name__ == "__main__":
    game = DodgeGame()
    game.run()
