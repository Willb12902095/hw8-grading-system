import pygame
import random
import sys
import csv
import os
import datetime

# 初始化 Pygame
pygame.init()

# 設定遊戲視窗參數
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("躲避方塊遊戲 - 滑鼠控制版")

# 隱藏滑鼠游標，增加沉浸感
pygame.mouse.set_visible(False)

# 定義顏色
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLACK = (0, 0, 0)

# 玩家與敵人參數
player_size = 50
# 玩家初始 Y 軸位置固定
player_y = HEIGHT - player_size - 10
# X 軸位置稍後由滑鼠決定
player_x = 0 

enemy_size = 50
enemy_speed = 5
enemies = []

# 自定義事件：增加敵人
ADD_ENEMY_EVENT = pygame.USEREVENT + 1
pygame.time.set_timer(ADD_ENEMY_EVENT, 500)

# 遊戲變數
clock = pygame.time.Clock()
font = pygame.font.Font(None, 36)
score = 0
running = True

# --- 處理成績紀錄的函數 ---
def update_high_scores(new_score):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(script_dir, 'highscores.csv')
    
    scores = []
    
    if os.path.exists(file_path):
        with open(file_path, mode='r', newline='', encoding='utf-8') as file:
            reader = csv.reader(file)
            for row in reader:
                if len(row) == 2 and row[0].isdigit():
                    scores.append((int(row[0]), row[1]))
    
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    scores.append((new_score, current_time))
    
    scores.sort(key=lambda x: x[0], reverse=True)
    top_10_scores = scores[:10]
    
    with open(file_path, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerows(top_10_scores)
        
    return top_10_scores

# --- 遊戲主迴圈 ---
while running:
    # 事件處理迴圈：檢查所有發生的事件 (如鍵盤、滑鼠點擊)
    for event in pygame.event.get():
        # 如果事件是關閉視窗 (點擊 'X')
        if event.type == pygame.QUIT:
            running = False
        # 如果事件是我們自訂的「新增敵人」事件
        elif event.type == ADD_ENEMY_EVENT:
            # 隨機決定敵人的出生 X 座標
            e_x = random.randint(0, WIDTH - enemy_size)
            # 建立一個敵人的矩形物件並加入到敵人列表中
            enemies.append(pygame.Rect(e_x, 0, enemy_size, enemy_size))
 
    # --- 滑鼠控制核心邏輯 ---
    # 取得滑鼠在視窗內的當前座標 (x, y)
    mouse_pos = pygame.mouse.get_pos()
    mouse_x = mouse_pos[0]
 
    # 計算玩家 X 座標：讓方塊中心對齊滑鼠
    player_x = mouse_x - (player_size // 2)
 
    # 邊界限制：防止玩家方塊超出螢幕左右兩側
    if player_x < 0:
        player_x = 0
    elif player_x > WIDTH - player_size:
        player_x = WIDTH - player_size
 
    # 根據計算好的座標，建立/更新玩家的矩形物件
    player_rect = pygame.Rect(player_x, player_y, player_size, player_size)
 
    # --- 遊戲狀態更新 ---
 
    # 遍歷所有敵人，讓它們向下移動
    for enemy in enemies:
        enemy.y += enemy_speed
    # 使用列表生成式，過濾掉所有已經掉出畫面底部的敵人，以節省資源
    enemies = [e for e in enemies if e.y < HEIGHT]
 
    # 碰撞偵測
    for enemy in enemies:
        # 檢查玩家的矩形是否與任何一個敵人的矩形發生碰撞
        if player_rect.colliderect(enemy):
            print(f"遊戲結束！最終分數: {score}")
 
            # 遊戲結束，將滑鼠游標重新顯示出來
            pygame.mouse.set_visible(True)
 
            # 更新並取得最高分紀錄
            top_scores = update_high_scores(score)
            print("--- 歷史前 10 名 ---")
            # 顯示排行榜
            for rank, (s, t) in enumerate(top_scores, 1):
                print(f"第 {rank} 名: {s} 分 ({t})")
            
            # 將 running 設為 False 來結束遊戲主迴圈
            running = False
 
    # 只要遊戲還在進行，分數就持續增加
    score += 1
 
    # --- 畫面繪製 ---
 
    # 用黑色填滿整個螢幕，清除上一幀的畫面
    screen.fill(BLACK)
    # 在螢幕上繪製綠色的玩家方塊
    pygame.draw.rect(screen, GREEN, player_rect)
    # 遍歷所有敵人，並將它們繪製在螢幕上
    for enemy in enemies:
        pygame.draw.rect(screen, RED, enemy)
 
    # 產生分數文字的圖像
    score_text = font.render(f"Score: {score}", True, WHITE)
    # 將分數文字圖像繪製到螢幕左上角 (10, 10) 的位置
    screen.blit(score_text, (10, 10))
 
    # 更新整個螢幕的顯示內容
    pygame.display.flip()
    # 控制遊戲迴圈每秒最多執行 60 次 (60 FPS)
    clock.tick(60)
 
# --- 遊戲結束 ---
# 結束 Pygame 程式
pygame.quit()
# 結束 Python 腳本執行
sys.exit()