import pygame
import sys

# Configuration
TILE_SIZE = 32
ROWS = 20
COLS = 19
WIDTH = COLS * TILE_SIZE
HEIGHT = ROWS * TILE_SIZE
SPEED = 2

# Colors
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
RED = (255, 0, 0)
WHITE = (255, 255, 255)

# Map: 1=Wall, 0=Empty, 2=Pellet
MAP_LAYOUT = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,2,1,1,1,1,1,2,1,2,1,1,2,1],
    [1,2,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,2,1],
    [1,1,1,1,2,1,1,1,0,1,0,1,1,1,2,1,1,1,1],
    [0,0,0,1,2,1,0,0,0,0,0,0,0,1,2,1,0,0,0],
    [1,1,1,1,2,1,0,1,1,0,1,1,0,1,2,1,1,1,1],
    [1,2,2,2,2,0,0,1,0,0,0,1,0,0,2,2,2,2,1],
    [1,1,1,1,2,1,0,1,1,1,1,1,0,1,2,1,1,1,1],
    [0,0,0,1,2,1,0,0,0,0,0,0,0,1,2,1,0,0,0],
    [1,1,1,1,2,1,2,1,1,1,1,1,2,1,2,1,1,1,1],
    [1,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,2,1,2,2,2,2,2,0,2,2,2,2,2,1,2,2,1],
    [1,1,2,1,2,1,2,1,1,1,1,1,2,1,2,1,2,1,1],
    [1,2,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,2,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
]

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Pac-Man Python")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont('arial', 20)
        self.score = 0
        self.game_over = False
        
        self.pacman_pos = [TILE_SIZE * 1, TILE_SIZE * 1]
        self.pacman_dir = [0, 0]
        self.next_dir = [0, 0]
        
        self.ghosts = [
            {'pos': [9 * TILE_SIZE, 8 * TILE_SIZE], 'dir': [1, 0], 'color': RED},
            {'pos': [9 * TILE_SIZE, 9 * TILE_SIZE], 'dir': [-1, 0], 'color': (255, 182, 193)}, # Pink
            {'pos': [10 * TILE_SIZE, 9 * TILE_SIZE], 'dir': [0, -1], 'color': (0, 255, 255)}  # Cyan
        ]

    def is_wall(self, x, y):
        col = int((x + TILE_SIZE // 2) // TILE_SIZE)
        row = int((y + TILE_SIZE // 2) // TILE_SIZE)
        if 0 <= row < len(MAP_LAYOUT) and 0 <= col < len(MAP_LAYOUT[0]):
            return MAP_LAYOUT[row][col] == 1
        return True

    def eat_pellet(self):
        col = int((self.pacman_pos[0] + TILE_SIZE // 2) // TILE_SIZE)
        row = int((self.pacman_pos[1] + TILE_SIZE // 2) // TILE_SIZE)
        if 0 <= row < len(MAP_LAYOUT) and 0 <= col < len(MAP_LAYOUT[0]):
            if MAP_LAYOUT[row][col] == 2:
                MAP_LAYOUT[row][col] = 0
                self.score += 10

    def move_entity(self, pos, direction):
        new_x = pos[0] + direction[0] * SPEED
        new_y = pos[1] + direction[1] * SPEED
        if not self.is_wall(new_x, new_y):
            pos[0] = new_x
            pos[1] = new_y
            return True
        else:
            # Snap to grid
            col = round(pos[0] / TILE_SIZE)
            row = round(pos[1] / TILE_SIZE)
            pos[0] = col * TILE_SIZE
            pos[1] = row * TILE_SIZE
            return False

    def update(self):
        if self.game_over: return

        # Pacman direction change
        # Only turn if centered
        if self.next_dir != [0, 0]:
            center_x = self.pacman_pos[0] % TILE_SIZE == 0
            center_y = self.pacman_pos[1] % TILE_SIZE == 0
            # Simplified: allow turn if not wall
            if not self.is_wall(self.pacman_pos[0] + self.next_dir[0] * TILE_SIZE, 
                                self.pacman_pos[1] + self.next_dir[1] * TILE_SIZE):
                 # Check alignment roughly
                 if abs(self.pacman_pos[0] % TILE_SIZE) < SPEED and abs(self.pacman_pos[1] % TILE_SIZE) < SPEED:
                     self.pacman_pos[0] = round(self.pacman_pos[0] / TILE_SIZE) * TILE_SIZE
                     self.pacman_pos[1] = round(self.pacman_pos[1] / TILE_SIZE) * TILE_SIZE
                     self.pacman_dir = list(self.next_dir)
                     self.next_dir = [0, 0]

        self.move_entity(self.pacman_pos, self.pacman_dir)
        self.eat_pellet()

        # Ghosts
        import random
        for ghost in self.ghosts:
            moved = self.move_entity(ghost['pos'], ghost['dir'])
            if not moved or random.random() < 0.02:
                opts = [[1,0], [-1,0], [0,1], [0,-1]]
                valid = []
                for d in opts:
                    if not self.is_wall(ghost['pos'][0] + d[0]*TILE_SIZE, ghost['pos'][1] + d[1]*TILE_SIZE):
                        valid.append(d)
                if valid:
                    ghost['dir'] = random.choice(valid)
            
            # Collision
            if abs(ghost['pos'][0] - self.pacman_pos[0]) < TILE_SIZE/2 and \
               abs(ghost['pos'][1] - self.pacman_pos[1]) < TILE_SIZE/2:
                self.game_over = True

    def draw(self):
        self.screen.fill(BLACK)
        
        # Draw Map
        for r, row in enumerate(MAP_LAYOUT):
            for c, val in enumerate(row):
                if val == 1:
                    pygame.draw.rect(self.screen, BLUE, (c*TILE_SIZE, r*TILE_SIZE, TILE_SIZE, TILE_SIZE), 1)
                elif val == 2:
                    pygame.draw.circle(self.screen, (255, 182, 147), (c*TILE_SIZE + TILE_SIZE//2, r*TILE_SIZE + TILE_SIZE//2), 4)

        # Draw Pacman
        pygame.draw.circle(self.screen, YELLOW, (int(self.pacman_pos[0] + TILE_SIZE//2), int(self.pacman_pos[1] + TILE_SIZE//2)), TILE_SIZE//2 - 2)

        # Draw Ghosts
        for ghost in self.ghosts:
            pygame.draw.circle(self.screen, ghost['color'], (int(ghost['pos'][0] + TILE_SIZE//2), int(ghost['pos'][1] + TILE_SIZE//2)), TILE_SIZE//2 - 2)

        # UI
        score_text = self.font.render(f"Score: {self.score}", True, WHITE)
        self.screen.blit(score_text, (10, HEIGHT - 30))
        
        if self.game_over:
            over_text = self.font.render("GAME OVER", True, RED)
            self.screen.blit(over_text, (WIDTH//2 - 50, HEIGHT//2))

        pygame.display.flip()

    def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP: self.next_dir = [0, -1]
                    elif event.key == pygame.K_DOWN: self.next_dir = [0, 1]
                    elif event.key == pygame.K_LEFT: self.next_dir = [-1, 0]
                    elif event.key == pygame.K_RIGHT: self.next_dir = [1, 0]
            
            self.update()
            self.draw()
            self.clock.tick(60)

if __name__ == "__main__":
    Game().run()
