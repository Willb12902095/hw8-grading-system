import pygame
import sys
import random
import os

# 初始化 Pygame
pygame.init()

# --- 常數設定 ---
WIDTH, HEIGHT = 800, 600
FPS = 60

# 顏色定義 (R, G, B)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)     # 敵人顏色
BLUE = (0, 0, 255)    # 玩家顏色
GREEN = (0, 255, 0)   # 碰撞時顏色

# 建立視窗
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("PyGame 碰撞檢測範例")
clock = pygame.time.Clock()

# 取得檔案路徑
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# --- 類別定義 ---

class Player(pygame.sprite.Sprite):
    """玩家類別 (由使用者控制)"""
    def __init__(self):
        super().__init__()
        # 載入玩家圖片 i001.gif
        img_path = os.path.join(BASE_DIR, "i001.gif")
        try:
            self.image = pygame.image.load(img_path).convert_alpha()
            self.image = pygame.transform.scale(self.image, (50, 50))
        except (FileNotFoundError, pygame.error):
            # 找不到圖片時的備用方案
            self.image = pygame.Surface((50, 50))
            self.image.fill(BLUE)
            # 畫個 'P' 代表 Player
            font = pygame.font.Font(None, 40)
            self.image.blit(font.render("P", True, WHITE), (15, 12))
        self.rect = self.image.get_rect()
        # 初始位置在畫面中央偏左
        self.rect.center = (WIDTH // 4, HEIGHT // 2)
        self.speed = 5

    def update(self):
        # 取得按鍵狀態
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.rect.x += self.speed
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            self.rect.y += self.speed

        # 限制玩家不能跑出視窗外
        if self.rect.left < 0: self.rect.left = 0
        if self.rect.right > WIDTH: self.rect.right = WIDTH
        if self.rect.top < 0: self.rect.top = 0
        if self.rect.bottom > HEIGHT: self.rect.bottom = HEIGHT

class Enemy(pygame.sprite.Sprite):
    """敵人類別 (自動移動)"""
    def __init__(self):
        super().__init__()
        # 載入敵人圖片 b001.gif
        img_path = os.path.join(BASE_DIR, "b001.gif")
        try:
            self.image = pygame.image.load(img_path).convert_alpha()
            self.image = pygame.transform.scale(self.image, (50, 50))
        except (FileNotFoundError, pygame.error):
            # 找不到圖片時的備用方案
            self.image = pygame.Surface((50, 50))
            self.image.fill(RED)
            # 畫個 'E' 代表 Enemy
            font = pygame.font.Font(None, 40)
            self.image.blit(font.render("E", True, WHITE), (15, 12))
        self.rect = self.image.get_rect()
        # 隨機初始位置 (避免太靠近邊緣)
        self.rect.x = random.randrange(0, WIDTH - self.rect.width)
        self.rect.y = random.randrange(0, HEIGHT - self.rect.height)
        # 隨機速度 (範圍 -5 到 5，排除 0)
        self.speed_x = random.choice([-5, -4, -3, 3, 4, 5])
        self.speed_y = random.choice([-5, -4, -3, 3, 4, 5])

    def update(self):
        # 自動移動
        self.rect.x += self.speed_x
        self.rect.y += self.speed_y

        # 碰到邊界反彈
        if self.rect.left < 0 or self.rect.right > WIDTH:
            self.speed_x *= -1
        if self.rect.top < 0 or self.rect.bottom > HEIGHT:
            self.speed_y *= -1

# --- 主程式 ---
def main():
    # 建立精靈群組 (方便管理和繪製)
    all_sprites = pygame.sprite.Group()
    enemies = pygame.sprite.Group()

    # 建立物件
    player = Player()
    all_sprites.add(player)

    # 建立多個敵人 (例如 10 個)
    for i in range(10):
        enemy = Enemy()
        all_sprites.add(enemy)
        enemies.add(enemy)

    font = pygame.font.Font(None, 74)
    running = True

    # 載入背景圖片
    bg_path = os.path.join(BASE_DIR, "tumblr_p47tbsTSXJ1wzlvpdo1_1280.gif")
    background = None
    try:
        background = pygame.image.load(bg_path).convert()
        background = pygame.transform.scale(background, (WIDTH, HEIGHT))
    except (FileNotFoundError, pygame.error):
        pass

    while running:
        # 1. 事件處理
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # 檢查按鍵狀態 (支援 Q 或 ESC 離開)
        keys = pygame.key.get_pressed()
        if keys[pygame.K_q] or keys[pygame.K_ESCAPE]:
            running = False

        # 2. 更新所有精靈狀態
        all_sprites.update()

        # 3. 碰撞檢測
        # spritecollide(主體, 目標群組, 是否刪除目標)
        hits = pygame.sprite.spritecollide(player, enemies, False)

        # 4. 畫面繪製
        if background:
            screen.blit(background, (0, 0))
        else:
            screen.fill(WHITE) # 清除畫面
            
        all_sprites.draw(screen) # 繪製所有精靈

        if hits:
            # 如果發生碰撞
            text = font.render("Collision!", True, BLACK)
            text_rect = text.get_rect(center=(WIDTH // 2, HEIGHT // 2))
            screen.blit(text, text_rect)

        pygame.display.flip() # 更新視窗
        clock.tick(FPS)       # 控制 FPS

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()