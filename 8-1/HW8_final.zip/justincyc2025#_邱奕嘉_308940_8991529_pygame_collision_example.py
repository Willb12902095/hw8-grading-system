import pygame
import random
import os

# 初始化 Pygame
pygame.init()

# 螢幕設定
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame 碰撞檢測範例")

# 顏色定義
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)

# 字型設定
font = pygame.font.Font(None, 36) # 使用預設字型，大小 36

# 載入圖片資源
try:
    # 獲取腳本所在的目錄，確保能找到圖片
    script_dir = os.path.dirname(os.path.abspath(__file__))
    player_img = pygame.image.load(os.path.join(script_dir, 'download.jpg')).convert_alpha()
    enemy_img = pygame.image.load(os.path.join(script_dir, 'images.jpg')).convert_alpha()
    background = pygame.image.load(os.path.join(script_dir, '7iQn8pf2xC.jpg')).convert()
    background = pygame.transform.scale(background, (SCREEN_WIDTH, SCREEN_HEIGHT))
except pygame.error as e:
    print(f"無法載入圖片資源: {e}")
    pygame.quit()
    exit()

# 玩家類別
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.transform.scale(player_img, (50, 50))
        self.rect = self.image.get_rect()
        self.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        self.speed = 5

    def update(self):
        # 獲取按鍵狀態
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += self.speed
        if keys[pygame.K_UP]:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN]:
            self.rect.y += self.speed

        # 限制玩家在螢幕範圍內
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT

# 敵人類別
class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.transform.scale(enemy_img, (40, 40))
        self.rect = self.image.get_rect()
        # 隨機生成敵人的初始位置
        self.rect.x = random.randrange(SCREEN_WIDTH - self.rect.width)
        self.rect.y = random.randrange(SCREEN_HEIGHT - self.rect.height)
        self.speed_x = random.choice([-2, 2]) # 敵人水平移動速度
        self.speed_y = random.choice([-2, 2]) # 敵人垂直移動速度

    def update(self):
        # 敵人移動
        self.rect.x += self.speed_x
        self.rect.y += self.speed_y

        # 敵人碰到邊界時反彈
        if self.rect.left < 0 or self.rect.right > SCREEN_WIDTH:
            self.speed_x *= -1
        if self.rect.top < 0 or self.rect.bottom > SCREEN_HEIGHT:
            self.speed_y *= -1

# 創建精靈群組
all_sprites = pygame.sprite.Group()
enemies = pygame.sprite.Group()

# 創建玩家
player = Player()
all_sprites.add(player)

# 創建敵人
for i in range(5): # 創建5個敵人
    enemy = Enemy()
    all_sprites.add(enemy)
    enemies.add(enemy)

# 分數
score = 0

# 遊戲迴圈
running = True
clock = pygame.time.Clock()

while running:
    # 事件處理
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 更新所有精靈
    all_sprites.update()

    # 碰撞檢測
    # pygame.sprite.spritecollide(sprite, group, dokill)
    # dokill=True 會在碰撞後從 group 中移除精靈。
    # 這裡我們將它設為 True，這樣每次碰撞只會計分一次。
    collided_enemies = pygame.sprite.spritecollide(player, enemies, True)
    if collided_enemies:
        score += len(collided_enemies)
        print(f"玩家碰到敵人了！ 目前分數: {score}")
        # 重新生成被吃掉的敵人
        for _ in range(len(collided_enemies)):
            new_enemy = Enemy()
            all_sprites.add(new_enemy)
            enemies.add(new_enemy)

    # 繪製
    screen.blit(background, (0, 0)) # 繪製背景
    all_sprites.draw(screen) # 繪製所有精靈

    # 繪製分數
    score_text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(score_text, (10, 10))

    # 更新顯示
    pygame.display.flip()

    # 控制遊戲幀率
    clock.tick(60) # 每秒60幀

# 退出 Pygame
pygame.quit()