import pygame
import random
import sys

# 初始化 Pygame
pygame.init()

# --- 遊戲常數設定 ---
WIDTH, HEIGHT = 800, 600
PLAYER_SIZE = 50
ENEMY_SIZE = 50
PLAYER_COLOR = (0, 255, 0)  # 綠色
ENEMY_COLOR = (255, 0, 0)   # 紅色
BG_COLOR = (0, 0, 0)        # 黑色背景
TEXT_COLOR = (255, 255, 255) # 白色文字
FPS = 60
PLAYER_SPEED = 7
ENEMY_SPEED = 5
ENEMY_SPAWN_RATE = 20  # 數字越小產生越快

# 設定螢幕
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("方塊閃避遊戲")

# 設定字型
font = pygame.font.SysFont("monospace", 35)
game_over_font = pygame.font.SysFont("monospace", 50)

def main():
    clock = pygame.time.Clock()
    
    # 玩家初始位置 (螢幕底部中間)
    player = pygame.Rect(WIDTH // 2 - PLAYER_SIZE // 2, HEIGHT - PLAYER_SIZE - 10, PLAYER_SIZE, PLAYER_SIZE)
    
    enemies = []
    score = 0
    start_time = pygame.time.get_ticks()
    game_over = False

    while True:
        # 1. 事件處理
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            # 遊戲結束後按任意鍵重啟
            if game_over and event.type == pygame.KEYDOWN:
                main() # 重新開始遊戲

        if not game_over:
            # 2. 玩家移動邏輯
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT] and player.x > 0:
                player.x -= PLAYER_SPEED
            if keys[pygame.K_RIGHT] and player.x < WIDTH - PLAYER_SIZE:
                player.x += PLAYER_SPEED
            if keys[pygame.K_UP] and player.y > 0:
                player.y -= PLAYER_SPEED
            if keys[pygame.K_DOWN] and player.y < HEIGHT - PLAYER_SIZE:
                player.y += PLAYER_SPEED

            # 3. 敵人生成邏輯
            # 隨機生成敵人 (機率控制)
            if random.randint(1, ENEMY_SPAWN_RATE) == 1:
                enemy_x = random.randint(0, WIDTH - ENEMY_SIZE)
                new_enemy = pygame.Rect(enemy_x, -ENEMY_SIZE, ENEMY_SIZE, ENEMY_SIZE)
                enemies.append(new_enemy)

            # 4. 敵人移動與清理
            # 複製一份列表進行迭代，以便安全移除元素
            for enemy in enemies[:]:
                enemy.y += ENEMY_SPEED
                # 如果敵人超出螢幕底部，將其移除
                if enemy.y > HEIGHT:
                    enemies.remove(enemy)
                
                # 5. 碰撞檢測
                if player.colliderect(enemy):
                    game_over = True

            # 6. 計算分數 (存活時間：秒)
            current_time = pygame.time.get_ticks()
            score = (current_time - start_time) // 1000

        # --- 繪圖階段 ---
        screen.fill(BG_COLOR)

        # 繪製敵人
        for enemy in enemies:
            pygame.draw.rect(screen, ENEMY_COLOR, enemy)

        # 繪製玩家
        pygame.draw.rect(screen, PLAYER_COLOR, player)

        # 顯示分數
        score_text = font.render(f"Score: {score}", 1, TEXT_COLOR)
        screen.blit(score_text, (10, 10))

        # 顯示遊戲結束畫面
        if game_over:
            end_text = game_over_font.render("GAME OVER", 1, TEXT_COLOR)
            restart_text = font.render("Press Any Key to Restart", 1, TEXT_COLOR)
            
            # 將文字置中
            text_rect = end_text.get_rect(center=(WIDTH/2, HEIGHT/2 - 50))
            restart_rect = restart_text.get_rect(center=(WIDTH/2, HEIGHT/2 + 20))
            
            screen.blit(end_text, text_rect)
            screen.blit(restart_text, restart_rect)

        pygame.display.update()
        clock.tick(FPS)

if __name__ == "__main__":
    main()