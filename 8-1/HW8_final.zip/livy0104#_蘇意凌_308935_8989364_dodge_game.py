import pygame
import random

# --- 常數設定 ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60

# 顏色
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
WHITE = (255, 255, 255)

# 玩家設定
PLAYER_WIDTH = 50
PLAYER_HEIGHT = 40 # 調整高度讓飛碟形狀更好看
PLAYER_SPEED = 5

# 敵人物件設定
ENEMY_WIDTH = 30
ENEMY_HEIGHT = 30
ENEMY_SPEED = 3
NUM_STARS = 150 # 星星數量


class Player(pygame.sprite.Sprite):
    """玩家角色(飛碟)類別"""
    def __init__(self):
        super().__init__()
        # 改用 pygame.SRCALPHA 讓 Surface 支援透明背景
        self.image = pygame.Surface((PLAYER_WIDTH, PLAYER_HEIGHT), pygame.SRCALPHA)
        # 繪製飛碟主體 (灰色橢圓)
        pygame.draw.ellipse(self.image, (150, 150, 150), [0, 15, PLAYER_WIDTH, 20])
        # 繪製駕駛艙 (綠色橢圓)
        pygame.draw.ellipse(self.image, GREEN, [15, 0, 20, 20])

        self.rect = self.image.get_rect()
        # 初始位置設定在畫面底部中央
        self.rect.centerx = SCREEN_WIDTH // 2
        self.rect.bottom = SCREEN_HEIGHT - 10  # 離底部保留一點距離
        self.speed = PLAYER_SPEED

    def update(self):
        """更新玩家位置，並處理邊界偵測"""
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += self.speed
        if keys[pygame.K_UP]:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN]:
            self.rect.y += self.speed

        # 邊界偵測，防止玩家移出視窗
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT


class Enemy(pygame.sprite.Sprite):
    """敵人類別(太空船)"""
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((ENEMY_WIDTH, ENEMY_HEIGHT), pygame.SRCALPHA)
        # 繪製太空船 (紅色倒三角形)
        pygame.draw.polygon(self.image, RED, [
            (ENEMY_WIDTH // 2, ENEMY_HEIGHT), # 底部尖端
            (0, 0),                         # 左上角
            (ENEMY_WIDTH, 0)                # 右上角
        ])
        self.rect = self.image.get_rect()
        # 初始位置從視窗上方隨機位置出現
        self.rect.x = random.randrange(SCREEN_WIDTH - self.rect.width)
        self.rect.y = random.randrange(-100, -40)
        self.speed = ENEMY_SPEED

    def update(self):
        """更新敵人位置，若掉出畫面則重置"""
        self.rect.y += self.speed
        # 當敵人掉出畫面底部時，重置到上方
        if self.rect.top > SCREEN_HEIGHT + 10:
            # TODO: 可以在這裡增加分數
            self.rect.x = random.randrange(SCREEN_WIDTH - self.rect.width)
            self.rect.y = random.randrange(-150, -50)


# --- 遊戲主程式 ---

# 1. 初始化 PyGame
pygame.init()

# 2. 建立視窗與標題
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("PyGame 練習 - 躲避遊戲")
clock = pygame.time.Clock()

# 建立星空背景
background = pygame.Surface(screen.get_size())
background = background.convert()
background.fill(BLACK)
for i in range(NUM_STARS):
    star_pos = (random.randrange(0, SCREEN_WIDTH), random.randrange(0, SCREEN_HEIGHT))
    pygame.draw.circle(background, WHITE, star_pos, random.randint(1, 2))

# 3. 建立遊戲物件與群組
all_sprites = pygame.sprite.Group()
enemies = pygame.sprite.Group()

player = Player()
all_sprites.add(player)

# 產生多個敵人
for _ in range(8):
    enemy = Enemy()
    all_sprites.add(enemy)
    enemies.add(enemy)

# 4. 遊戲主迴圈
running = True
while running:
    # 控制遊戲更新速度
    clock.tick(FPS)

    # --- 事件處理 ---
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # --- 狀態更新 ---
    all_sprites.update()

    # --- 碰撞偵測 ---
    # 檢查玩家是否與任何一個敵人發生碰撞
    # pygame.sprite.spritecollide 會回傳一個包含所有碰撞到的敵人的列表
    hits = pygame.sprite.spritecollide(player, enemies, False)
    if hits:
        print("Game Over!")
        running = False

    # --- 畫面繪製 ---
    # 繪製星空背景
    screen.blit(background, (0, 0))
    # 繪製所有 Sprite
    all_sprites.draw(screen)

    # 更新畫面
    pygame.display.flip()

# 遊戲結束，退出 PyGame
pygame.quit()