import pygame
import sys
import random

# 初始化 Pygame
pygame.init()

# 視窗設定
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("宇宙射擊 (Space Shooter)")

# 顏色定義
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 0, 0)
BLUE = (0, 0, 200)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)
ORANGE = (255, 165, 0)

# 遊戲參數
FPS = 60
PLAYER_SIZE = 50
MOVE_SPEED = 5
ATTACK_COOLDOWN = 15  # 玩家射擊間隔
ATTACK_DAMAGE = 25
PLAYER_BULLET_SPEED_Y = -12
PLAYER_BULLET_SPEED_X = 5

# 敵人參數
ENEMY_SIZE = 45
ENEMY_SPEED = 2
ENEMY_HP = 50
ENEMY_DAMAGE = 10
ENEMY_SPAWN_RATE = 60 # 每 60 幀 (約1秒) 產生一個敵人
ENEMY_ATTACK_COOLDOWN = 80
ENEMY_BULLET_SPEED = 6

class Bullet:
    def __init__(self, x, y, speed_x, speed_y, color, size=(5, 15)):
        self.rect = pygame.Rect(x, y, size[0], size[1])
        self.speed_x = speed_x
        self.speed_y = speed_y
        self.color = color

    def update(self):
        self.rect.x += self.speed_x
        self.rect.y += self.speed_y

    def draw(self, surface):
        pygame.draw.rect(surface, self.color, self.rect)

class Player:
    def __init__(self, x, y, color):
        # 使用 rect 進行碰撞檢測與定位
        self.rect = pygame.Rect(x, y, PLAYER_SIZE, PLAYER_SIZE - 10)
        self.color = color
        self.hp = 100
        self.max_hp = 100
        self.attack_timer = 0
        self.invincible_timer = 0

    def move(self, keys):
        dx, dy = 0, 0
        if keys[pygame.K_a]: dx = -MOVE_SPEED
        if keys[pygame.K_d]: dx = MOVE_SPEED
        if keys[pygame.K_w]: dy = -MOVE_SPEED
        if keys[pygame.K_s]: dy = MOVE_SPEED
        
        self.rect.x += dx
        self.rect.y += dy

        # 邊界限制
        if self.rect.left < 0: self.rect.left = 0
        if self.rect.right > SCREEN_WIDTH: self.rect.right = SCREEN_WIDTH
        if self.rect.top < 0: self.rect.top = 0
        if self.rect.bottom > SCREEN_HEIGHT: self.rect.bottom = SCREEN_HEIGHT

        # 計時器更新
        if self.attack_timer > 0: self.attack_timer -= 1
        if self.invincible_timer > 0: self.invincible_timer -= 1

    def attack(self, player_bullets):
        self.attack_timer = ATTACK_COOLDOWN
        bullet_x = self.rect.centerx - 2
        bullet_y = self.rect.top
        # 往左前和右前同時發射
        player_bullets.append(Bullet(bullet_x, bullet_y, -PLAYER_BULLET_SPEED_X, PLAYER_BULLET_SPEED_Y, YELLOW))
        player_bullets.append(Bullet(bullet_x, bullet_y, PLAYER_BULLET_SPEED_X, PLAYER_BULLET_SPEED_Y, YELLOW))

    def take_damage(self, amount):
        if self.invincible_timer == 0:
            self.hp -= amount
            if self.hp < 0: self.hp = 0
            self.invincible_timer = 60 # 1秒無敵

    def draw(self, surface):
        # 無敵時閃爍
        if self.invincible_timer > 0 and self.invincible_timer % 10 < 5:
            return

        # 繪製三角形戰機
        points = [
            (self.rect.centerx, self.rect.top), 
            (self.rect.left, self.rect.bottom), 
            (self.rect.right, self.rect.bottom)
        ]
        pygame.draw.polygon(surface, self.color, points)

class Enemy:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, ENEMY_SIZE, ENEMY_SIZE)
        self.color = BLUE
        self.hp = ENEMY_HP
        self.attack_cooldown = ENEMY_ATTACK_COOLDOWN + random.randint(-20, 20)
        self.attack_timer = self.attack_cooldown

    def update(self, enemy_bullets):
        self.rect.y += ENEMY_SPEED
        self.attack_timer -= 1
        if self.attack_timer <= 0:
            self.attack(enemy_bullets)

    def attack(self, enemy_bullets):
        self.attack_timer = self.attack_cooldown
        bullet_x = self.rect.centerx - 2
        bullet_y = self.rect.bottom
        enemy_bullets.append(Bullet(bullet_x, bullet_y, 0, ENEMY_BULLET_SPEED, ORANGE))

    def take_damage(self, amount):
        self.hp -= amount

    def draw(self, surface):
        pygame.draw.rect(surface, self.color, self.rect)
        # 血條
        pygame.draw.rect(surface, RED, (self.rect.x, self.rect.y - 15, ENEMY_SIZE, 8))
        hp_width = int(ENEMY_SIZE * (self.hp / ENEMY_HP))
        pygame.draw.rect(surface, GREEN, (self.rect.x, self.rect.y - 15, hp_width, 8))

def draw_text(text, size, color, x, y):
    font = pygame.font.Font(None, size)
    surface = font.render(text, True, color)
    rect = surface.get_rect()
    rect.midtop = (x, y)
    screen.blit(surface, rect)

def draw_player_hp(hp, max_hp):
    bar_width = 200
    bar_height = 25
    hp_percent = hp / max_hp
    current_width = bar_width * hp_percent
    pygame.draw.rect(screen, RED, (20, 20, bar_width, bar_height))
    pygame.draw.rect(screen, GREEN, (20, 20, current_width, bar_height))
    draw_text(f"HP: {hp}/{max_hp}", 22, WHITE, 20 + bar_width/2, 22)

def main():
    clock = pygame.time.Clock()
    p1 = Player(SCREEN_WIDTH // 2 - PLAYER_SIZE // 2, SCREEN_HEIGHT - PLAYER_SIZE - 20, RED)
    enemies = []
    player_bullets = []
    enemy_bullets = []
    score = 0
    enemy_spawn_timer = 0
    stars = [(random.randint(0, SCREEN_WIDTH), random.randint(0, SCREEN_HEIGHT), random.randint(1, 2)) for _ in range(100)]
    running = True
    game_over = False

    while running:
        clock.tick(FPS)
        
        # 1. 事件處理
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r and game_over:
                    # 重置遊戲
                    p1 = Player(SCREEN_WIDTH // 2 - PLAYER_SIZE // 2, SCREEN_HEIGHT - PLAYER_SIZE - 20, RED)
                    enemies = []
                    player_bullets = []
                    enemy_bullets = []
                    score = 0
                    game_over = False

        # 2. 遊戲邏輯更新
        keys = pygame.key.get_pressed()
        
        if not game_over:
            # 玩家移動與攻擊
            p1.move(keys)
            if keys[pygame.K_SPACE] and p1.attack_timer == 0:
                p1.attack(player_bullets)

            # 更新玩家子彈
            for bullet in player_bullets[:]:
                bullet.update()
                if bullet.rect.bottom < 0:
                    player_bullets.remove(bullet)

            # 敵人生成
            enemy_spawn_timer += 1
            if enemy_spawn_timer >= ENEMY_SPAWN_RATE:
                enemy_spawn_timer = 0
                x_pos = random.randint(0, SCREEN_WIDTH - ENEMY_SIZE)
                enemies.append(Enemy(x_pos, -ENEMY_SIZE)) # 從螢幕上方出現

            # 更新敵人與敵人子彈
            for enemy in enemies[:]:
                enemy.update(enemy_bullets)
                if enemy.rect.top > SCREEN_HEIGHT:
                    enemies.remove(enemy)

            for bullet in enemy_bullets[:]:
                bullet.update()
                if bullet.rect.top > SCREEN_HEIGHT:
                    enemy_bullets.remove(bullet)

            # 碰撞檢測
            # 玩家子彈 vs 敵人
            for bullet in player_bullets[:]:
                for enemy in enemies[:]:
                    if bullet.rect.colliderect(enemy.rect):
                        enemy.take_damage(ATTACK_DAMAGE)
                        if bullet in player_bullets: player_bullets.remove(bullet)
                        if enemy.hp <= 0:
                            if enemy in enemies: enemies.remove(enemy)
                            score += 10
            
            # 敵人子彈 vs 玩家
            for bullet in enemy_bullets[:]:
                if p1.rect.colliderect(bullet.rect):
                    p1.take_damage(ENEMY_DAMAGE)
                    if bullet in enemy_bullets: enemy_bullets.remove(bullet)
            
            # 敵人 vs 玩家
            for enemy in enemies[:]:
                if p1.rect.colliderect(enemy.rect):
                    p1.take_damage(ENEMY_DAMAGE * 2) # 直接碰撞傷害更高
                    if enemy in enemies: enemies.remove(enemy)

            # 檢查遊戲結束
            if p1.hp <= 0:
                game_over = True

        # 3. 畫面繪製
        screen.fill(BLACK)
        for star in stars: pygame.draw.circle(screen, WHITE, (star[0], star[1]), star[2])
        for bullet in player_bullets: bullet.draw(screen)
        for bullet in enemy_bullets: bullet.draw(screen)
        for enemy in enemies: enemy.draw(screen)
        p1.draw(screen)
        # UI 資訊
        draw_player_hp(p1.hp, p1.max_hp)
        draw_text(f"Score: {score}", 30, WHITE, SCREEN_WIDTH - 100, 20)
        draw_text("WASD: Move | SPACE: Shoot", 22, WHITE, SCREEN_WIDTH // 2, 20)

        if game_over:
            draw_text("GAME OVER", 80, YELLOW, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 100)
            draw_text(f"Final Score: {score}", 50, WHITE, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
            draw_text("Press 'R' to Restart", 40, WHITE, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 100)

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()